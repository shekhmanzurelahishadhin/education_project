<table border="1">
    <tr>
        <td>{{$name}}</td>
        <td>{{$email}}</td>
        <td>{{$number}}</td>
        <td>{{$Subject}}</td>
        <td>{{$message}}</td>
    </tr>
</table>
